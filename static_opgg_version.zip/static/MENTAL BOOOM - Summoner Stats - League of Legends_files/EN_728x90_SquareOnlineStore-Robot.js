(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:



(lib.robot1 = function() {
	this.initialize(img.robot1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,672,560);


(lib.robot2 = function() {
	this.initialize(img.robot2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,672,560);


(lib.robot3 = function() {
	this.initialize(img.robot3);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,672,560);


(lib.Tween7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AVNGpQgfghAAg2QAAg2AegiQAhgkA3AAQA1AAAeAiQAeAgAAA0IgBAXIieAAQAAAWAQAMQAOALAYAAQAjAAAWgbIAqApQgnAuhBAAQg4AAgigjgAXTE1QgCgVgMgMQgMgMgUAAQgTAAgOANQgNAMgBAUIBdAAIAAAAgAPdG5QgXgUAAgiQAAgnAegSQASgLAlgFQAggEAJgDQAPgFAAgMQAAgVgkAAQgnAAgiAVIgXgwQAUgNAbgHQAbgIAbAAQAuAAAZATQAbAUABAqIAACfIg/AAIAAgWQgXAcgpAAQglAAgWgTgARDFfIgZAFQgQADgHAFQgKAGAAAOQAAAZAeAAQATAAAMgKQANgMAAgUIAAgWQgFAEgLACgALZGjIAjgpQAeAeAwAAQAlAAAAgVQAAgKgMgFQgKgDgggFQgpgHgUgNQgcgSAAgkQAAglAfgVQAbgSAqAAQA+AAAoAlIgiAqQgLgMgTgHQgTgIgVAAQgPAAgKAEQgJAFgBAIQABALAPAFIAjAGQAwAIAWAPQAYASgBAgQAAAmgdAWQgcAWgxAAQhFAAgngpgAGJGpQgfghAAg2QAAg2AegiQAhgkA3AAQA1AAAfAiQAeAgAAA0IgCAXIieAAQAAAWAQAMQAOALAYAAQAkAAAVgbIAqApQgnAuhAAAQg6AAghgjgAIPE1QgBgWgNgLQgNgMgSAAQgUAAgNANQgNAMgCAUIBdAAIAAAAgApwGqQgggigBg3QAAg3AhgiQAigiA3AAQA3AAAiAiQAhAiAAA3QAAA3ghAiQgiAig3AAQg3AAgigigAo8EhQgNASAAAeQAAAeANASQANASAYAAQAYAAAOgSQANgSAAgeQAAgegNgSQgOgSgYAAQgYAAgNASgAuJG6QgUgSAAgnIAAhwIgqAAIAAg1IAqAAIAAhQIBEAAIAABQIA3AAIAAA1Ig3AAIAABlQAAAdAaAAQANAAALgHIANAzQgTANgkAAQgmAAgSgSgAysGjIAjgpQAeAeAxAAQAkAAAAgVQAAgKgMgFQgKgDgggFQgogHgVgNQgbgSAAgkQAAglAegVQAbgSAqAAQA9AAAqAlIgjAqQgKgMgTgHQgUgIgWAAQgOAAgKAEQgJAFgBAIQAAALAQAFIAkAGQAvAIAWAPQAYASgBAgQAAAmgdAWQgbAWgyAAQhEAAgogpgAY0HGIAAhIIBJAAIAABIgATGHGIAAk6IBEAAIAAE6gAEEHGIAAiMQAAgogiAAQgTAAgMAMQgMANAAAWIAACFIhEAAIAAjqIBEAAIAAAZQALgOARgIQATgJAUAAQAlAAAVAZQAUAXAAAkIAACcgAgBHGIAAjqIBDAAIAADqgAh2HGIAAk6IBEAAIAAE6gAjpHGIAAiMQAAgoghAAQgUAAgLAMQgMANAAAWIAACFIhFAAIAAjqIBFAAIAAAZQALgOAQgIQASgJAVAAQAlAAAVAZQAUAXAAAkIAACcgA1OHGIAAjqIBEAAIAAAdQAXghAmAAQAVAAAJAHIgKA9QgIgGgTAAQgZAAgOASQgPATAAAkIAABngA3DHGIAAjqIBEAAIAADqgA5PHGIAAi1IgiAAIAAg1IAiAAIAAgTQAAgjASgQQASgPAnAAQAXAAAUAFIgIAyQgMgDgIAAQgXAAAAARIAAAQIAvAAIAAA1IgvAAIAAC1gAgBDDIAAg3IBDAAIAAA3gA3DDDIAAg3IBEAAIAAA3gATgidQgTgSAAgnIAAhwIgqAAIAAg1IAqAAIAAhQIBDAAIAABQIA5AAIAAA1Ig5AAIAABlQAAAdAaAAQAOAAAKgHIAOAzQgUANgkAAQglAAgTgSgAPOieQgXgUAAgiQAAgnAegSQASgLAlgFQAggEAIgDQAQgFABgMQAAgVglAAQgRAAgUAGQgUAGgQAJIgXgwQATgNAbgHQAcgIAbAAQAuAAAZATQAcAUgBAqIAACfIg/AAIAAgWQgVAcgqAAQglAAgWgTgAQ0j4IgaAFQgPADgHAFQgKAGAAAOQAAAZAeAAQATAAAMgKQAOgMAAgUIAAgWQgGAEgLACgAIyidQgUgSAAgnIAAhwIgqAAIAAg1IAqAAIAAhQIBDAAIAABQIA4AAIAAA1Ig4AAIAABlQAAAdAaAAQAOAAAKgHIANAzQgSANglAAQglAAgSgSgACiiuQgfghAAg2QAAg2AegiQAhgkA2AAQA2AAAeAiQAfAgAAA0IgBAXIifAAQAAAWAQAMQAOALAYAAQAkAAAVgbIAqApQgnAuhBAAQg4AAgigjgAEokiQgBgVgNgMQgMgMgUAAQgTAAgNANQgNAMgCAUIBdAAIAAAAgAlLieQgXgUAAgiQAAgnAegSQATgLAkgFQAggEAJgDQAQgFAAgMQAAgVglAAQgRAAgUAGQgUAGgQAJIgXgwQAUgNAagHQAcgIAbAAQAvAAAYATQAcAUAAAqIAACfIg/AAIAAgWQgXAcgpAAQglAAgWgTgAjlj4IgaAFQgPADgHAFQgKAGAAAOQAAAZAeAAQATAAAMgKQAOgMAAgUIAAgWQgGAEgLACgAxHikQgVgXAAgkIAAicIBEAAIAACMQAAAoAiAAQATAAAMgMQAMgNAAgWIAAiFIBEAAIAADqIhEAAIAAgZQgKAOgSAIQgSAJgVAAQglAAgUgZgA1QitQgggiAAg3QAAg3AggiQAigiA3AAQA4AAAhAiQAhAiAAA3QAAA3ghAiQghAig4AAQg3AAgigigA0ck2QgNASAAAeQAAAeANASQANASAYAAQAYAAANgSQAOgSAAgeQAAgegOgSQgNgSgYAAQgYAAgNASgANSiRIAAiMQAAgogiAAQgTAAgLAMQgNANAAAWIAACFIhEAAIAAk6IBEAAIAABpQAYgfAsAAQAkAAAVAZQATAXAAAkIAACcgAA+iRIg7hiIghAnIAAA7IhEAAIAAk6IBEAAIAACyIBThiIBPAAIhTBbIBdCPgAnGiRIAAiNQAAgngiAAQgRAAgLAMQgLAMAAAWIAACGIhEAAIAAiNQAAgnggAAQgTAAgLAMQgLAMAAAWIAACGIhDAAIAAjqIBDAAIAAAZQAXgfAqAAQAXAAARALQAQAKAIASQAbgnAwAAQAkAAAVAYQATAXAAAkIAACdgA4MiRIAAiCIhwi4IBSAAIBCB2IBDh2IBRAAIhyC4IAACCg");
	this.shape.setTransform(200.5,0.9875,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(117.5,-22,166.10000000000002,46);


(lib.Tween5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AAsCAIgsijIgtCjIg8AAIhBkAIA+AAIAlCrIAwirIAuAAIAwCsIAkisIBAAAIhEEAg");
	this.shape.setTransform(22.65,1.55);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AhdCAIAAkAIC6AAIAAA0IiAAAIAAAzIBzAAIAAAtIhzAAIAABsg");
	this.shape_1.setTransform(-5.2,1.55);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgcCAIAAjMIhOAAIAAg0IDWAAIAAA0IhQAAIAADMg");
	this.shape_2.setTransform(-28.5,1.55);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-42.3,-23.6,84.6,47.2);


(lib.Symbol2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AhABGQgZgbAAgqQAAgqAYgbQAZgcAqAAQApAAAYAaQAXAZAAAoIgBAPIiCAAQAAAXAOAMQANAMAVAAQAfAAASgXIAcAcQgeAjgxAAQgrAAgagbgAAugUQgCgUgMgLQgLgLgSAAQgSAAgMAMQgMALgCATIBXAAIAAAAg");
	this.shape.setTransform(-153.5125,0.6875,0.5,0.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("Ag7BfIAAi5IAtAAIAAAYQAIgMANgIQANgIAQAAQAQAAAIAHIgIAoQgIgFgOAAQgUAAgLAPQgNAQAAAdIAABXg");
	this.shape_1.setTransform(-161.3875,0.5875,0.5,0.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AhDBGQgagbAAgrQAAgqAagbQAagbApAAQArAAAZAbQAaAbAAAqQAAArgaAbQgZAbgrAAQgpAAgagbgAghgpQgMAQAAAZQAAAaAMAQQAMARAVAAQAWAAANgRQAMgQAAgaQAAgZgMgQQgNgRgWAAQgVAAgMARg");
	this.shape_2.setTransform(-170.7625,0.6875,0.5,0.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgeBHIAAhgIgiAAIAAgkIAiAAIAAhCIAsAAIAABCIAuAAIAAAkIguAAIAABZQAAAaAWAAQALgBAIgFIAKAjQgOAJgaAAQg3AAAAg5g");
	this.shape_3.setTransform(-179.4125,-0.85,0.5,0.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("Ag6B0QgbgOgPgYIAlgZQAKAUAUAJQARAJAUgBQAXABAOgKQANgKAAgQQAAgQgQgJQgLgFgcgHQgqgIgVgMQgdgTAAgjQAAgiAbgVQAZgSApAAQA/AAAgAuIgjAYQgVgfgoAAQgTABgNAHQgNAJAAAOQAAALAKAIQAIAFASAFQA7AQAMAFQAoAUAAAoQAAAigaAWQgbAYgtAAQgigBgbgOg");
	this.shape_4.setTransform(-188.2625,-0.95,0.5,0.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AhABGQgZgbAAgqQAAgqAYgbQAZgcAqAAQApAAAYAaQAXAZAAAoIgBAPIiCAAQAAAXAOAMQANAMAVAAQAfAAASgXIAcAcQgeAjgxAAQgrAAgagbgAAugUQgCgUgMgLQgLgLgSAAQgSAAgMAMQgMALgCATIBXAAIAAAAg");
	this.shape_5.setTransform(-203.5625,0.6875,0.5,0.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AAlBfIAAhwQAAglggAAQgRAAgMAMQgMAMAAAVIAABoIgtAAIAAi5IAtAAIAAAYQAUgcAkAAQAdAAAQATQARASAAAeIAAB6g");
	this.shape_6.setTransform(-213.775,0.575,0.5,0.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgVB+IAAi5IArAAIAAC5gAgVhWIAAgnIArAAIAAAng");
	this.shape_7.setTransform(-221.2375,-0.9625,0.5,0.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgWB+IAAj7IAsAAIAAD7g");
	this.shape_8.setTransform(-225.75,-0.9625,0.5,0.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AAlBfIAAhwQAAglggAAQgRAAgMAMQgMAMAAAVIAABoIgtAAIAAi5IAtAAIAAAYQAUgcAkAAQAdAAARATQAQASAAAeIAAB6g");
	this.shape_9.setTransform(-233.1625,0.575,0.5,0.5);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AhZBdQgiglABg4QgBg4AigkQAiglA3AAQA4AAAiAlQAiAkgBA4QABA4giAlQgiAlg4ABQg3gBgiglgAg2g9QgUAYAAAlQAAAnAUAXQAUAYAiAAQAiAAAVgYQATgXABgnQgBglgTgYQgVgZgiABQgigBgUAZg");
	this.shape_10.setTransform(-245.025,-0.95,0.5,0.5);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AhABGQgZgbAAgqQAAgqAYgbQAZgcAqAAQApAAAYAaQAXAZAAAoIgBAPIiCAAQAAAXAOAMQANAMAVAAQAfAAASgXIAcAcQgeAjgxAAQgrAAgagbgAAugUQgCgUgMgLQgLgLgSAAQgSAAgMAMQgMALgCATIBXAAIAAAAg");
	this.shape_11.setTransform(-261.6375,0.6875,0.5,0.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("Ag7BfIAAi5IAtAAIAAAYQAIgMANgIQANgIAQAAQAQAAAIAHIgIAoQgIgFgOAAQgUAAgLAPQgNAQAAAdIAABXg");
	this.shape_12.setTransform(-269.5125,0.5875,0.5,0.5);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("Ag9BSQgSgPAAgbQAAgeAYgNQAOgJAbgEQAbgEAHgCQAPgGAAgLQAAgUghAAQggAAgZASIgQghQAhgWAsAAQAiAAAUAOQAUAQAAAfIAACAIgqAAIAAgUQgTAYgiAAQgdAAgRgPgAASAIIgWAEQgPADgHAEQgJAHAAAMQAAAYAdAAQARAAAMgKQANgKgBgUIAAgVQgFAEgMADg");
	this.shape_13.setTransform(-278.7,0.6875,0.5,0.5);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AhABMQgRgSAAgfIAAh5IAtAAIAABvQAAAmAgAAQASAAAMgMQAMgMAAgVIAAhoIAsAAIAAC5IgsAAIAAgXQgVAbgjAAQgdAAgRgTg");
	this.shape_14.setTransform(-288.475,0.7875,0.5,0.5);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AAwB+IAAhWQgTAdglAAQgmAAgXgcQgXgbAAgpQAAgrAXgbQAXgcAmAAQAkAAAUAcIAAgYIAtAAIAAD3gAghhFQgMAQAAAZQAAAaALAPQANARAVAAQAXAAANgRQAMgQAAgZQAAgZgMgQQgNgRgXAAQgVAAgMARg");
	this.shape_15.setTransform(-299.3625,2.1125,0.5,0.5);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("Ag6B0QgbgOgPgYIAlgZQAKAUAUAJQARAJAUgBQAXABAOgKQANgKAAgQQAAgQgQgJQgLgFgcgHQgqgIgVgMQgdgTAAgjQAAgiAbgVQAZgSApAAQA/AAAgAuIgjAYQgKgOgQgJQgRgHgSgBQgTABgNAHQgNAJAAAOQAAALAKAIQAIAFASAFQA7AQAMAFQAoAUAAAoQAAAigaAWQgbAYgtAAQgigBgbgOg");
	this.shape_16.setTransform(-310.2125,-0.95,0.5,0.5);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#4376F6").s().p("AioDrQgZgEgSgSQgSgTgFgZIAAgbIAAkaIAAgbQAFgZASgSQASgTAZgEQAGgBAWAAIEYAAQAXAAAFABQAZAEATATQASASAEAZIABAbIAAEaIgBAbQgEAZgSATQgTASgZAEgAiLiKQgHAGAAAKIAAD2QAAAKAHAGQAHAHAJAAID2AAQAKAAAGgHQAIgGAAgKIAAj2QAAgKgIgGQgGgHgKAAIj2AAQgJAAgHAHgAgtBBQgIAAgCgBQgGgBgCgHQgBgCAAgIIAAhaQAAgIABgCQACgHAGgBQACgBAIAAIBaAAQAIAAACABQAHABACAHQABACAAAIIAABaQAAAIgBACQgCAHgHABQgCABgIAAg");
	this.shape_17.setTransform(-334.75,0.2375,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-346.5,-11.5,197.5,23.5);


(lib.robot = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// robot3.png
	this.instance = new lib.robot3();
	this.instance.parent = this;
	this.instance.setTransform(-168,-140,0.5,0.5);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(2).to({_off:false},0).wait(1));

	// robot2.png
	this.instance_1 = new lib.robot2();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-168,-140,0.5,0.5);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({_off:false},0).to({_off:true},1).wait(1));

	// robot1.png
	this.instance_2 = new lib.robot1();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-168,-140,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({_off:true},2).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-168,-140,336,280);


(lib.cta = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AIGBWIANgVQAOAMAVAAQAjAAAAggIAAgIQgMARgYAAQgXABgOgRQgPgQAAgXQAAgYAPgRQAOgQAXAAQAZAAALASIAAgPIAcAAIAABfQAAAbgMAOQgRATghAAQgeAAgTgOgAImgZQgHAJAAAPQAAANAHAJQAIAKANAAQAOAAAJgKQAHgJAAgNQAAgPgHgJQgJgKgOAAQgNAAgIAKgABnAtQgQgRAAgaQAAgZAPgRQAQgSAbAAQAZAAAPAQQAPAQAAAZIgBAJIhSAAQAAAOAJAIQAIAIAOgBQATAAALgOIASARQgTAXgfgBQgbAAgQgRgACsgKQgBgNgIgHQgHgGgLgBQgMAAgHAIQgIAGgBANIA3AAIAAAAgAgaA2QgRgJgJgPIAXgPQAGALANAHQAKAFANAAQAOAAAJgGQAIgGAAgKQAAgLgKgFQgHgCgSgEQgZgFgNgIQgSgNAAgVQAAgWARgMQAPgMAYAAQAoAAAVAcIgWAQQgNgUgaABQgLAAgIAEQgIAGAAAJQAAAMAVAGQAkAJAJAEQAZAMAAAZQAAAVgQAOQgRAOgcAAQgVAAgRgIgAi0AbIAAg8IgVAAIAAgWIAVAAIAAgqIAcAAIAAAqIAcAAIAAAWIgcAAIAAA4QAAAPAOAAQAHAAAFgDIAGAVQgJAHgQgBQgjAAAAgjgAmIA1QgLgKAAgRQAAgSAOgIQAJgFASgDIAVgEQAKgDAAgHQAAgMgVgBQgVABgPAKIgKgUQAUgOAcAAQAvAAAAAmIAABQIgbAAIAAgNQgLAQgWgBQgSAAgLgJgAllAJQgTAFAAALQAAAQATAAQALgBAHgFQAIgHAAgMIAAgOQgEAEgWADgAnaAbIAAg8IgVAAIAAgWIAVAAIAAgqIAcAAIAAAqIAdAAIAAAWIgdAAIAAA4QAAAPAOAAQAHAAAFgDIAGAVQgJAHgQgBQgjAAAAgjgAp0AeIAXgPQANAXAdAAQAPAAAIgGQAJgGAAgKQAAgLgLgFQgGgCgSgEQgbgFgMgIQgTgNAAgVQAAgWARgMQAQgMAZAAQAoAAAUAcIgWAQQgNgUgaABQgLAAgIAEQgIAGAAAJQAAAMAWAGQAkAJAJAEQAZAMAAAZQAAAVgRAOQgQAOgdAAQgsAAgUgggAHQA8IAAhFQAAgYgUAAQgLAAgHAHQgIAIAAANIAABBIgcAAIAAhzIAcAAIAAAOQANgRAWAAQASAAALAMQAKALAAATIAABMgAFOA8IAAhzIAcAAIAABzgAEWA8IAAidIAcAAIAACdgADdA8IAAidIAcAAIAACdgAkUA8IAAhzIAcAAIAAAPQAJgRAWAAIAHABIAAAXQgmAAAAAmIAAA3gAFOhIIAAgZIAcAAIAAAZg");
	this.shape.setTransform(-0.9625,0.725,0.5,0.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#4376F6").s().p("AwvD1QgRAAgLgLQgMgMAAgRIAAmZQAAgRAMgLQALgMARAAMAhfAAAQARAAALAMQAMALAAARIAAGZQAAARgMAMQgLALgRAAg");
	this.shape_1.setTransform(-0.4125,0.25,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-56,-12,111.2,24.5);


(lib.btn_clickTag = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#5A4099").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape.setTransform(150,125);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,300,250);


(lib.mc = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var stage = this;
		
		this.clickTag_btn.addEventListener("click", fl_MouseClickHandler.bind(this));
		
		function fl_MouseClickHandler()
		{
			window.open(window.clickTag);
		}
	}
	this.frame_201 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(201).call(this.frame_201).wait(1));

	// clickTag
	this.clickTag_btn = new lib.btn_clickTag();
	this.clickTag_btn.name = "clickTag_btn";
	this.clickTag_btn.parent = this;
	this.clickTag_btn.setTransform(214.1,-79.9,2.4267,0.36,0,0,0,150,124.9);
	new cjs.ButtonHelper(this.clickTag_btn, 0, 1, 2, false, new lib.btn_clickTag(), 3);

	this.timeline.addTween(cjs.Tween.get(this.clickTag_btn).wait(202));

	// logo
	this.instance = new lib.Symbol2("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(214,-80);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(202));

	// cta
	this.instance_1 = new lib.cta("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(495.6,-79.8);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(154).to({_off:false},0).to({alpha:1},13).wait(35));

	// text 2
	this.instance_2 = new lib.Tween7("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(113.05,-82.95);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(106).to({_off:false},0).to({alpha:1},14).wait(82));

	// text 1
	this.instance_3 = new lib.Tween5("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(270.3,-81.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(90).to({startPosition:0},0).to({alpha:0},14).to({_off:true},1).wait(97));

	// robot
	this.instance_4 = new lib.robot("single",0);
	this.instance_4.parent = this;
	this.instance_4.setTransform(214.3,-138.9,1.1232,1.1232);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(44).to({startPosition:1},0).wait(61).to({startPosition:2},0).wait(97));

	// white
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Eg0fArwMAAAhXfMBo/AAAMAAABXfg");
	this.shape.setTransform(213.988,-80.0024,1.0833,0.1607);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(202));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-150,-296.1,728.1,314.5);


// stage content:
(lib.EN_728x90_SquareOnlineStoreRobot = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// border
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#333333").ss(2,1,1,3,true).p("Eg43gHBMBxvAAAIAAODMhxvAAAg");
	this.shape.setTransform(364,45);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_1
	this.mainMC = new lib.mc();
	this.mainMC.name = "mainMC";
	this.mainMC.parent = this;
	this.mainMC.setTransform(150,125);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(363,-126.1,366,269.5);
// library properties:
lib.properties = {
	id: '799ECBC2007340CBAFE9AE4EEE2EA081',
	width: 728,
	height: 90,
	fps: 60,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/robot1.png?1568901533707", id:"robot1"},
		{src:"images/robot2.png?1568901533707", id:"robot2"},
		{src:"images/robot3.png?1568901533707", id:"robot3"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['799ECBC2007340CBAFE9AE4EEE2EA081'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;